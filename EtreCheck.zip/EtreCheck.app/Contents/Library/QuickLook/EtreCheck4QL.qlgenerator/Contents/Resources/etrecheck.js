$(document).ready(
  function()
    {
    // Override the copy operation without harming validation.
    $('body').bind(
      {
      copy : 
        function()
          {
          docopy();
          }
      });
      
    // Don't allow context menu.
    $('body').bind(
      {
      contextmenu : 
        function(event)
          {
          event.preventDefault();
          }
      });
    }); 
    
// Issue a REST GET request.
function GET(path)
  {
  var queryString = null;

  var queryStart = path.indexOf('?');
  
  if(queryStart != -1)
    {
    queryString = path.substring(queryStart + 1);
    path = path.substring(0, queryStart);
    }
    
  $.ajax(
    {
    url: path,
    data: queryString, 
    success: 
      function(result)
        {
        }
    });
  }

// Keep track of whether or not unmounted volumes are visible.
var unmountedVolumesVisible = false;

// Show unmounted volumes.
function showUnmountedVolumes()
  {
  $(".notmounted").fadeIn();
  $(".container").fadeIn();
  $(".container").prev('tr').removeClass('last_child');
  $("#hide_unmounted_volumes").fadeIn();
  $("#show_unmounted_volumes").fadeOut();
  
  unmountedVolumesVisible = true;
  }
  
// Hide unmounted volumes.
function hideUnmountedVolumes()
  {
  $(".notmounted").fadeOut();
  $(".container").fadeOut();
  $("#show_unmounted_volumes").fadeIn();
  $("#hide_unmounted_volumes").fadeOut({
    complete:
      function ()
        {
        $(".container").prev('tr').addClass('last_child');
        }
    });
    
  unmountedVolumesVisible = false;
  }
  
// Scroll to a device.
function showPartition(event, device)
  {
  // Don't jump to #.
  event.preventDefault();
  
  if(!unmountedVolumesVisible)
    showUnmountedVolumes();
  
  focusOnElementById(device);
  }
  
function focusOnElementById(id)
  {
  $container = $("div.scrollfix");
  
  $container.animate(
    { 
    scrollTop: 
      $("#" + id).offset().top 
        - $container.offset().top 
        + $container.scrollTop()
    }, 
    500,
    "swing",
    function()
      {
      $("#" + id).addClass("flash");
      });
  }
  
// Get the current scroll position.
function getCurrentScrollTop()
  {
  return $("div.scrollfix").scrollTop();
  }
  
// Restore the current scroll position.
function setCurrentScrollTop(scrollTop)
  {
  return $("div.scrollfix").scrollTop(scrollTop);
  }
  
// Show Apple files having a givent status and type (agent/daemon).
function showAppleFiles(showButton, status, type, last_row)
  {
  $(".apple." + status + "." + type).fadeIn();
  $(showButton).next().fadeIn();
  $(showButton).fadeOut();
  
  if(last_row)
    $(showButton).parent().closest('tr').removeClass('last_child');
  }
  
// Hide Apple files having a givent status and type (agent/daemon).
function hideAppleFiles(hideButton, status, type, last_row)
  {
  $(".apple." + status + "." + type).fadeOut();
  $(hideButton).prev().fadeIn();
  $(hideButton).fadeOut(
    {
    complete: 
      function()
        {
        if(last_row)
          $(hideButton).parent().closest('tr').addClass('last_child');
        }
    });  
  }

// Jump to a specific section.
function jump(section, anchor)
  {
  // Don't jump to #.
  event.preventDefault();

  var path = "/jump/" + section;
  
  if(anchor != "")
    path += "/" + anchor;
    
  GET(path);
  }
  
// Intercept the copy operation.
function docopy()
  {
  GET("/copy");
  }

// Unload a launchd file.
function unload(identifier)
  {
  GET('/launchd/unload/' + identifier);
  }
  
// Load a launchd file.
function load(identifier)
  {
  GET('/launchd/load/' + identifier);
  }
  
// Perform a live update.
function performLiveUpdate(identifier, status, statusString)
  {
  if(identifier.startsWith("launchd"))
    updateLaunchdFile(identifier, status, statusString);
  else if(identifier.startsWith("safariextension"))
    updateSafariExtension(idenifier, status, statusString);
  }
  
// Update a launchd file.
function updateLaunchdFile(identifier, status, statusString)
  {
  if(status == "deleted")
    {
    $("." + identifier).remove();

    if($(".adware tbody").length == 0)
      $(".adware").remove();

    if($(".launchagents tbody").length == 0)
      $(".launchagents").remove();

    if($(".launchdaemons tbody").length == 0)
      $(".launchdaemons").remove();

    if($(".userlaunchagents tbody").length == 0)
      $(".userlaunchagents").remove();
    }
    
  $("." + identifier + " .status").html(statusString);
  
  if(status == "loaded")
    {
    $("." + identifier + " button.load").attr("disabled", "disabled");
    $("." + identifier + " button.unload").removeAttr("disabled");
    $("." + identifier + " .status img.spinner").remove();
    $("." + identifier + " button.reveal_config").removeAttr("disabled");
    
    $("." + identifier + " button.reveal_executable").removeAttr(
      "disabled");
    }
  else if(status == "notloaded")
    {
    $("." + identifier + " button.unload").attr("disabled", "disabled");
    $("." + identifier + " button.load").removeAttr("disabled");
    $("." + identifier + " .status img.spinner").remove();
    $("." + identifier + " button.reveal_config").removeAttr("disabled");
    
    $("." + identifier + " button.reveal_executable").removeAttr(
      "disabled");
    }
  else if(status == "removing")
    {
    $("." + identifier + " .status").append(
      "<img class='spinner' src='/image/Spinner.svg'>");
      
    $("." + identifier + " button.unload").attr("disabled", "disabled");
    $("." + identifier + " button.load").attr("disabled", "disabled");
    
    $("." + identifier + " button.reveal_config").attr(
      "disabled", "disabled");
      
    $("." + identifier + " button.reveal_executable").attr(
      "disabled", "disabled");
    }
  }
  
// Update a Safari extension.
function updateSafariExtension(identifier, status, statusString)
  {
  if(status == "deleted")
    $("." + identifier).remove();
    
  if($(".adware tr").length == 1)
    $(".adware").remove();
  }
  
// Update Gatekeeper.
function updateGatekeeper(statusString)
  {
  $("#gatekeeperstatus").html(statusString);
  }
  
// Remove an item from a section.
function removeItem(item, sectionName)
  {
  var section = $("." + sectionName);
  
  if($("tbody", section).length == 1)
    $(section).fadeOut(
      {
      complete: 
        function()
          {
          $(section).remove();
          }
      });
  else
    $("." + item, section).fadeOut(
      {
      complete: 
        function()
          {
          $("." + item, section).remove();
          }
      });
  }
